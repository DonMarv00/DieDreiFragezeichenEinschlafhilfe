package de.msdevs.einschlafhilfe;


import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.v7.widget.CardView;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;

import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.ViewFlipper;
import android.widget.Toast;



import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Wir sollten eine Network Library benutzen +
        //Quellcode in einer sprache halten
        //NavBar stand abspeichern +
        // Funktion zum bewerten und kommentieren
        //Die drei Fragezeichen Kids


        ImageView image_btn_left = (ImageView) findViewById(R.id.btn_left);
        image_btn_left.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ViewFlipper vf_change = (ViewFlipper) findViewById(R.id.ViewFlipper);
                vf_change.showPrevious();

            }
        });


        ImageView image_btn_right = (ImageView) findViewById(R.id.btn_right);
        image_btn_right.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ViewFlipper vf_change = (ViewFlipper) findViewById(R.id.ViewFlipper);
                vf_change.showNext();


            }
        });

        //Damit eine Folge direkt beim Start angezeigt wird.
        ServerConnection("4", "1");

        ImageView iv_refresh = (ImageView)findViewById(R.id.iv_refresh);
        iv_refresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                //Dies ist einfacher als mit den SharedPreferences zu arbeiten, da man nicht die Strings auswendig lernen muss, um einen besseren
                //Workflow zuhaben.
                ViewFlipper vf_change = (ViewFlipper) findViewById(R.id.ViewFlipper);
                if (vf_change.getDisplayedChild() == 0) {
                    ServerConnection("1" ,"1");
                }

                if (vf_change.getDisplayedChild() == 1) {
                    ServerConnection("2", "1");
                }
                if (vf_change.getDisplayedChild() == 2) {
                    ServerConnection("4", "1");
                }
                if (vf_change.getDisplayedChild() == 3) {
                    ServerConnection("5" ,"1");
                }
                if (vf_change.getDisplayedChild() == 4) {
                    ServerConnection("3" ,"1");
                }
                if (vf_change.getDisplayedChild() == 5) {
                    ServerConnection("6" ,"1");
                }


            }
        });
        CardView cv_btn_folgenliste = (CardView)findViewById(R.id.cv_btn_folgen_liste);
        cv_btn_folgenliste.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                folgen_liste();

            }
        });
    }
    public void folgen_liste(){
        TextView tv_folgen_id = (TextView)findViewById(R.id.textView_folgen_nummer);
        String folgen_id = tv_folgen_id.getText().toString();
        String folgen_id_dd = tv_folgen_id.getText().toString() + "_dd";
        CardView cv_btn_folgenliste = (CardView)findViewById(R.id.cv_btn_folgen_liste);
        ImageView iv_folgen_liste = (ImageView)findViewById(R.id.iv_folgen_liste);
        TextView tv_folgen_liste = (TextView)findViewById(R.id.tv_folgen_liste);




        ViewFlipper vf_change = (ViewFlipper) findViewById(R.id.ViewFlipper);
        if (vf_change.getDisplayedChild() == 3) {
            SharedPreferences sp_folgen_liste = getSharedPreferences("folgen_liste", 0);
            String folge_sp_loaded = sp_folgen_liste.getString(folgen_id_dd,"");
            if(folge_sp_loaded == "true") {


                SharedPreferences.Editor editor = sp_folgen_liste.edit();
                editor.putString(folgen_id + "_dd", "false");
                editor.commit();
                tv_folgen_liste.setText("Diese Folge habe ich nicht");

            }else{

                SharedPreferences.Editor editor = sp_folgen_liste.edit();
                editor.putString(folgen_id + "_dd" , "true");
                editor.commit();
                tv_folgen_liste.setText("Diese Folge habe ich");
            }
            folgen_liste_checker();
        }else{
            SharedPreferences sp_folgen_liste = getSharedPreferences("folgen_liste", 0);
            String folge_sp_loaded = sp_folgen_liste.getString(folgen_id,"");
            if(folge_sp_loaded == "true") {

                SharedPreferences.Editor editor = sp_folgen_liste.edit();
                editor.putString(folgen_id, "false");
                editor.commit();
                tv_folgen_liste.setText("Diese Folge habe ich nicht");
            }else{

                SharedPreferences.Editor editor = sp_folgen_liste.edit();
                editor.putString(folgen_id, "true");
                editor.commit();
                tv_folgen_liste.setText("Diese Folge habe ich");
            }
            folgen_liste_checker();
        }

    }
    public void folgen_liste_checker(){
        TextView tv_folgen_id = (TextView)findViewById(R.id.textView_folgen_nummer);
        String folgen_id = tv_folgen_id.getText().toString();
        String folgen_id_dd = tv_folgen_id.getText().toString() + "_dd";
        ImageView iv_folgen_liste = (ImageView)findViewById(R.id.iv_folgen_liste);
        TextView tv_folgen_liste = (TextView)findViewById(R.id.tv_folgen_liste);

        ViewFlipper vf_change = (ViewFlipper) findViewById(R.id.ViewFlipper);
        if (vf_change.getDisplayedChild() == 3) {
            SharedPreferences sp_folgen_liste = getSharedPreferences("folgen_liste", 0);
            String folge_sp_loaded = sp_folgen_liste.getString(folgen_id_dd,"");


            if(folge_sp_loaded == ""){
                iv_folgen_liste.setImageDrawable(null);
                tv_folgen_liste.setText("Hast du diese Folge?");
            }else{
                if(folge_sp_loaded == "true"){
                    iv_folgen_liste.setImageDrawable(getResources().getDrawable(R.drawable.ic_action_yes));
                }else{
                    iv_folgen_liste.setImageDrawable(getResources().getDrawable(R.drawable.ic_action_no));
                }
            }



        }else{
            SharedPreferences sp_folgen_liste = getSharedPreferences("folgen_liste", 0);
            String folge_sp_loaded = sp_folgen_liste.getString(folgen_id,"");
            if(folge_sp_loaded == ""){
                iv_folgen_liste.setImageDrawable(null);
            }else {
                if (folge_sp_loaded == "true") {
                    iv_folgen_liste.setImageDrawable(getResources().getDrawable(R.drawable.ic_action_yes));
                } else {
                    iv_folgen_liste.setImageDrawable(getResources().getDrawable(R.drawable.ic_action_no));
                }
            }
        }



    }
    public void ServerConnection(final String data, final String op){

        final String server_url = "https://marvin-stelter.de/ddf/server_script.php";

        if(data.equals("ignore")) {
            Toast.makeText(getApplicationContext(), "Dies funktioniert noch nicht.", Toast.LENGTH_SHORT).show();
        }else {
            //Dies sollte in einen AsyncTask laufen.


            new Thread(new Runnable() {
                @Override
                public void run() {

                    try {

                        String textparam = "data=" + URLEncoder.encode(data, "UTF-8");
                        String textparam_b = "bewerten=" + URLEncoder.encode(data, "UTF-8");


                        URL scripturl = new URL(server_url);
                        HttpURLConnection connection = (HttpURLConnection) scripturl.openConnection();
                        connection.setDoOutput(true);
                        connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                        if(op == "1") {
                            connection.setFixedLengthStreamingMode(textparam.getBytes().length);
                            OutputStreamWriter contentWriter = new OutputStreamWriter(connection.getOutputStream());
                            contentWriter.write(textparam);
                            contentWriter.flush();
                            contentWriter.close();

                        }else{
                            connection.setFixedLengthStreamingMode(textparam_b.getBytes().length);
                            OutputStreamWriter contentWriter = new OutputStreamWriter(connection.getOutputStream());
                            contentWriter.write(textparam_b);
                            contentWriter.flush();
                            contentWriter.close();
                        }


                        InputStream answerInputStream = connection.getInputStream();
                        //Der Text aus dem Output des PHP Skriptes wird in einem EditText Feld angezeigt.
                        final String answer = getTextFromInputStream(answerInputStream);

                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {

                                DisplayServerResults(answer, data);
                                ProgressBar pg_loading = (ProgressBar)findViewById(R.id.progressBar);
                                pg_loading.setVisibility(View.GONE);

                            }
                        });
                        answerInputStream.close();
                        connection.disconnect();


                    } catch (MalformedURLException e) {
                        e.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }).start();
        }

    }
    public String getTextFromInputStream(InputStream is){
        BufferedReader reader = new BufferedReader(new InputStreamReader(is));
        StringBuilder stringBuilder = new StringBuilder();
        //echo output des PHP Skriptes
        String aktuelleZeile;
        try {
            while ((aktuelleZeile = reader.readLine()) != null){
                stringBuilder.append(aktuelleZeile);
                stringBuilder.append("\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return stringBuilder.toString().trim();
    }
    public void DisplayServerResults(String results, String data){

        try {
            // Server Daten splitten und anzeigen.
            String[] folgen_Daten = results.split(":");

            String folgen_name = folgen_Daten[0];
            String folgen_nummer = folgen_Daten[1];
            String  folgen_bewertung_gut = folgen_Daten[2];
            String  folgen_bewertung_schlecht = folgen_Daten[3];


            TextView tv_folgen_nummer = (TextView) findViewById(R.id.textView_folgen_nummer);
            TextView tv_folgen_name = (TextView) findViewById(R.id.textView_folgen_name);


            if(folgen_name != "") {
                tv_folgen_name.setText(folgen_name);
                tv_folgen_nummer.setText(folgen_nummer);


                folgen_liste_checker();
            }else{
                //Keine Daten wurden empfangen, wir senden eine Anfrage erneut zum Server
                ServerConnection(data, "1");
            }


        }catch (Exception e){

        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {


            case R.id.about_me:
                Intent i_three = new Intent(MainActivity.this, AboutActivity.class);
                startActivity(i_three);

                break;


            default:
                break;

        }
        return true;
    }


}
