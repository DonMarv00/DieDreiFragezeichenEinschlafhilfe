package de.msdevs.einschlafhilfe;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

/**
 * Created by hp on 10.11.2018.
 */

public class AboutActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.about_me);

        Button btn_instagram = (Button)findViewById(R.id.btn_instagram);
        Button btn_internet_seite = (Button)findViewById(R.id.btn_website);
        Button btn_github = (Button)findViewById(R.id.btn_github);

        btn_instagram.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                openWebsite("https://instagram.com/marvin_stelter");
            }
        });
        btn_internet_seite.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                openWebsite("https://marvin-stelter.de/");
            }
        });
        btn_github.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                openWebsite("https://github.com/MarvinStelter");
            }
        });
    }
    public void openWebsite(String url){
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setData(Uri.parse(url));
        startActivity(i);
    }
}
