package de.msdevs.einschlafhilfe;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.AdapterView.*;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


/**
 * Created by hp on 08.11.2018.
 */

public class FolgenListeActivity extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.setup_layout);

        Button btn_folgen_nummer_hinzufügen = (Button) findViewById(R.id.btn_nummer_hinzufügen);
        btn_folgen_nummer_hinzufügen.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                EditText et_nummer = (EditText) findViewById(R.id.editText_folgen_nummer);
                String nummer = et_nummer.getText().toString();
                sp_editor(nummer, "false");
            }
        });

        Button btn_alle = (Button) findViewById(R.id.btn_alle_folgen);
        btn_alle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                sp_editor("alle", "true");

            }
        });
    }
    public void sp_editor(String folge, String op){
        SharedPreferences sp_folge = getSharedPreferences(getPackageName(), 0);
        SharedPreferences.Editor editor_folge = sp_folge.edit();
        editor_folge.putString(folge, op);
        editor_folge.commit();

    }
    public  void finished(){
        Intent i = new Intent(FolgenListeActivity.this, MainActivity.class);
        startActivity(i);
    }

}
